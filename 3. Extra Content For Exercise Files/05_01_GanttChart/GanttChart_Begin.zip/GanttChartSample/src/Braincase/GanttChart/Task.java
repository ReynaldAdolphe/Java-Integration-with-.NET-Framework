package Braincase.GanttChart;

import com.javonet.Javonet;
import com.javonet.JavonetException;
import com.javonet.api.NObject;

public class Task {
	private NObject handle;
	
	public Task() throws JavonetException {
		handle = Javonet.New(this.getClass().getName());
	}
	public Task(NObject taskNObject) throws JavonetException {
		handle=taskNObject;
	}
	public void setName(String name) throws JavonetException
	{
		handle.set("Name",name);
	}
	
	public String getName() throws JavonetException {
		return handle.get("Name");
	}
}
