package System;

import com.javonet.Javonet;
import com.javonet.JavonetException;
import com.javonet.api.NObject;

public class TimeSpan {
	
	private NObject handle;
	
	public TimeSpan(int days,int hours, int minutes, int seconds) throws JavonetException
	{
		handle = Javonet.New("TimeSpan",days,hours,minutes,seconds);
	}
}
