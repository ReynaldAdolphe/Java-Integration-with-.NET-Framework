import java.awt.EventQueue;

import com.javonet.Javonet;
import com.javonet.JavonetApartmentState;
import com.javonet.JavonetException;
import com.javonet.JavonetFramework;

public class Program {

	public static void main(String[] args) {
		try {
			new Program();
		} catch (JavonetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
    public Program() throws JavonetException
    {
    	Javonet.setUsePrivateHandleField(true);
		Javonet.setApartmentState(JavonetApartmentState.STA);
		// TODO: Register for Javonet trial https://www.javonet.com/signup-for-trial/
		// TODO: Type the email address and license key (will be sent to your email)
		Javonet.activate("spamproof2010@gmail.com", "i2X7-x6DY-b2S8-Gc9q-n4T5",JavonetFramework.v45);
		Javonet.addReference("GanttChart.dll");
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					new Form();
				} catch (JavonetException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
    }
}
