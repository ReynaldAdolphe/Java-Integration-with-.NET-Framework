package Braincase.GanttChart;

import com.javonet.Javonet;
import com.javonet.JavonetException;
import com.javonet.api.NObject;

public class TaskMouseEventArgs {
	private NObject handle;
	
	public TaskMouseEventArgs() throws JavonetException{
		handle = Javonet.New(this.getClass().getName());
	}
	
	public TaskMouseEventArgs(NObject taskMouseEventArgsNObject) throws JavonetException{
		handle=taskMouseEventArgsNObject;
	}
	
	public Task getTask() throws JavonetException
	{
		return new Task(handle.getRef("Task"));
	}
}
