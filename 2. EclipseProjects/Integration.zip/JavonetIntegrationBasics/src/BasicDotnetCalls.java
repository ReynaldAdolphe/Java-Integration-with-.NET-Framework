import java.util.concurrent.atomic.AtomicReference;

import com.javonet.Javonet;
import com.javonet.JavonetException;
import com.javonet.JavonetFramework;
import com.javonet.api.NEnum;
import com.javonet.api.NObject;
import com.javonet.api.NType;
import com.javonet.api.keywords.NOut;
import com.javonet.api.keywords.NRef;

public class BasicDotnetCalls {

	public static void main(String[] args) throws JavonetException {
		// TODO Auto-generated method stub
		System.out.println("Rise & Shine & Ready to Test!");
		//Javonet.activate("javonettester@gmail.com", "t7JB-Yi56-b5M4-Bg42-Jn4g", JavonetFramework.v45);
		
		AddReferences();
		
		TestCarSDK();
		//TestStaticInstanceSDK();
		//TestFieldsPropertiesComponentSDK();
		//PassingArgumentsSDK1();
		//PassingArgumentsSDK2();
		//PassingArgumentsSDK2b();
		//PassingArgumentsSDK3();
		//PassingArraysSDK();
		TestEnums();
		
	}

	private static void AddReferences() throws JavonetException {		
		Javonet.addReference("CarComponent.dll");
		Javonet.addReference("StaticInstanceComponent.dll");
		Javonet.addReference("FieldsPropertiesComponent.dll");
		Javonet.addReference("PassingArgumentsSDK.dll");
		Javonet.addReference("PassingArraysComponent.dll");
		Javonet.addReference("EnumsComponent.dll");
		
	}

	// 01_04
	private static void TestCarSDK() throws JavonetException {
		System.out.println("\nExercise 01_04\n---------");
		NObject theCar = Javonet.New("CarSDK");
		String result = theCar.invoke("RevEngine");
		System.out.println(result);
	}
	
	// 03_01
	private static void TestStaticInstanceSDK() throws JavonetException {
		System.out.println("\nExercise 03_01\n---------");
		
		//Demo calling instance method
		NObject siaClass = Javonet.New("StaticInstanceSDK");
		int result = siaClass.invoke("MultiplyViaInstance",15,16);
		System.out.println(result);
		
		//Demo calling static method
		int result2 = Javonet.getType("StaticInstanceSDK").invoke("AddViaStatic",5,16);
		System.out.println(result2);
		
	}
	// 03_02
	private static void TestFieldsPropertiesComponentSDK() throws JavonetException {
		System.out.println("\nExercise 03_02\n---------------");
		
		// Demo of static field
		NType sampleType = Javonet.getType("FieldsPropertiesSDK");
		sampleType.set("MyStaticField", 10);
		Integer staticVal = sampleType.get("MyStaticField");
		System.out.println("MyStaticField output = " + staticVal);
		
		// Demo of instance field
		NObject sampleObj = Javonet.New("FieldsPropertiesSDK");
		sampleObj.set("MyInstanceField", 20);
		Integer instanceVal = sampleObj.get("MyInstanceField");
		System.out.println("MyInstanceField output = " + instanceVal);
		
	}
	
	// 03_03
	private static void PassingArgumentsSDK1() throws JavonetException {
		
		// Demo Passing Reference-Type Arguments
		NObject objectWithProp = Javonet.New("ObjectWithProp");
		objectWithProp.set("PropTextValue", "This is an alert stored in .NET object prop");
		
		NObject objectUsingObjectProp = Javonet.New("ObjectUsingObjectProp");
		objectUsingObjectProp.invoke("DisplayPropValue",objectWithProp);
		objectUsingObjectProp.set("ObjProperty", objectWithProp);
		
		System.out.println("\n*** Displaying the value of the property "
							+ "of an object instance that was set to the property ***\\n");
		
		System.out.println(objectUsingObjectProp.getRef("ObjProperty").get("PropTextValue").toString());		
	}
	//---------------------------------------------------------------------
	private static void PassingArgumentsSDK2() throws JavonetException {	
		System.out.println("\nExercise 03_03b1\n---------------");
		
		// Demo Passing Arguments by Reference with ref/out Keywords
     	NObject refEx = Javonet.New("RefExample");  
		
      	//Wrap Java integer in AtomicReference to allow passing by reference  
		AtomicReference<Integer> myInt = new AtomicReference<Integer>(10);  
  
		refEx.invoke("Method",new NRef(myInt));  
  
		System.out.println(myInt.get());  
		//Output will display number "54" (added 44+10) because int passed by reference has been modified within the method body.  
    
	}
	//---------------------------------------------------------------------
	private static void PassingArgumentsSDK2b() throws JavonetException {	
		System.out.println("\nExercise 03_03b2\n---------------");
		
		NObject populator = Javonet.New("PopulateItems");   
		
		//We must wrap java array with Atomic Reference so we can pass it as a reference to NOut argument
      	AtomicReference<NObject[]> itemsArray = new AtomicReference<NObject[]>(null);  
  
		populator.invoke("Populate", new NOut(itemsArray, "Item[]"));  
  		//After execution of this method local items array variable will contain five items generated within Populate method body.
    	
		//Retrieve updated array
		NObject[] items = itemsArray.get();

      	for (int i=0; i<items.length; i++)
        {
			System.out.println(items[i].get("ItemName").toString());
        }
	}

	//---------------------------------------------------------------------
	private static void PassingArgumentsSDK3() throws JavonetException {	
		System.out.println("\nExercise 03_03c\n---------------");
		
		// Demo Passing typeof(Type) as Method Argument
      	NObject sampleObj = Javonet.New("Sample");  
		sampleObj.invoke("PassTypeArg",Javonet.getType("String"));  
		//or  
		NType typeOfString = Javonet.getType("String");  
		sampleObj.invoke("PassTypeArg",typeOfString);  
      
	}
	// 03_04
	private static void PassingArraysSDK() throws JavonetException {
		System.out.println("\nExercise 03_04\n---------------");
		
		//Retrieving array of strings
		NObject sampleObj = Javonet.New("Class1");
		String[] items = sampleObj.invoke("GetItems"); 
		
		for (int i=0; i<items.length;i++) {
			System.out.println(items[i]);  
		}
		
		//Passing array of strings  
		String[] stringArray = new String[] {"Item1","Item2","Item3"};
		sampleObj.invoke("DisplayArray", new Object[] {stringArray});  
		
		//Retrieving array of .NET objects  
		NObject[] refArray = sampleObj.invoke("GetRefItems");
		for (int i=0; i<refArray.length;i++)  
    	{
			System.out.println(refArray[i].get("ObjectItemName").toString());
    	}
		
		//Passing array of .NET objects  
		sampleObj.invoke("DisplayArray",new Object[] {refArray});
		
	}
	// 03_05

	private static void TestEnums() throws JavonetException {
		System.out.println("\nExercise 03_05\n---------------");
		//Invoke instance of EnumDemo
		NObject sampleObj = Javonet.New("EnumDemo");
		
		//Set enum as property value  
		sampleObj.set("EnumField", new NEnum("SampleEnum","ValueOne"));
		
		//Get enum from property  
		NEnum enumValue = sampleObj.<NEnum>get("EnumField");
		
		System.out.println(enumValue.getValueName());
		System.out.println(enumValue.getValue());
		
		//Pass enum as method argument  
		sampleObj.invoke("MethodA", enumValue);
		
		//Check enum value  
		if (enumValue.equals(new NEnum("SampleEnum","ValueTwo"))) {
			System.out.println("Enum returned from EnumField equals ValueTwo");  
		}else {
			System.out.println("Enum returned from EnumField does not equal to ValueTwo");  
		}
		
		
	}

	
}
