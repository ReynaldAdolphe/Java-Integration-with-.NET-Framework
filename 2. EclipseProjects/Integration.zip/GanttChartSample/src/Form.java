import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.javonet.JavonetException;
import com.javonet.api.NObject;

import Braincase.GanttChart.Chart;
import Braincase.GanttChart.ChartListener;
import Braincase.GanttChart.ProjectManager;
import Braincase.GanttChart.Task;
import Braincase.GanttChart.TaskMouseEventArgs;
import Braincase.GanttChart.TimeResolution;
import System.TimeSpan;

public class Form implements ChartListener{
	JFrame guiFrame;
	Chart ganttChart;
	JLabel lblHeader;
	
	public Form() throws JavonetException {
		initializeComponents();
	}
	
    private void initializeComponents() throws JavonetException
    {
    	guiFrame = new JFrame();
    
    	guiFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        guiFrame.setTitle("Gantt Chart Sample");
        guiFrame.setSize(980,500);
      
        guiFrame.setLayout(new BorderLayout());
        
        JPanel navigationBar = new JPanel();
        JPanel mainPanel = new JPanel();

		mainPanel.setLayout(new BorderLayout());
   
	    lblHeader = new JLabel();
		lblHeader.setText(".NET Gantt Chart User Control");
		lblHeader.setFont(new Font("Microsoft Sans Serif",0,20));
		navigationBar.add(lblHeader);
		
		guiFrame.add(mainPanel);
    	guiFrame.add(navigationBar,BorderLayout.NORTH);

		//Create GanttChart
		ganttChart = new Chart();
		ganttChart.setTimeResolution(TimeResolution.Day);
		
		ProjectManager mProject = new ProjectManager();
		
		ArrayList<Task> tasks = new ArrayList<Task>();
		
		Task task1 = new Task();
		task1.setName("Create Java Project");
		tasks.add(task1);
		
		Task task2 = new Task();
		task2.setName("Add .NET DLL files");
		tasks.add(task2);
		
		Task task3 = new Task();
		task3.setName("Take a break short 10 hour break.");
		tasks.add(task3);
		
		Random r = new Random();
		for (Task task : tasks)
		{
			mProject.add(task);
			mProject.setDuration(task, new TimeSpan(r.nextInt(40)+1,0,0,0));
			mProject.setStart(task, new TimeSpan(r.nextInt(10)+5,0,0,0));
			mProject.setComplete(task, r.nextFloat());
		}
		
		ganttChart.init(mProject);
		ganttChart.addChartListener(this);
		
		//Add user control to Java UI
		mainPanel.add(ganttChart, BorderLayout.CENTER);
        guiFrame.setVisible(true);
    }

	@Override
	public void TaskSelected(NObject sender, TaskMouseEventArgs args) throws JavonetException {
		lblHeader.setText("Selected Task: "+args.getTask().getName());
		lblHeader.setForeground(Color.red);		
	}

}
