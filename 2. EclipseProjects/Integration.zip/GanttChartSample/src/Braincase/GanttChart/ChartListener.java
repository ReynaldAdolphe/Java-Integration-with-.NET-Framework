package Braincase.GanttChart;

import com.javonet.JavonetException;
import com.javonet.api.NObject;

public interface ChartListener {
	public void TaskSelected(NObject sender, TaskMouseEventArgs args) throws JavonetException;
}
