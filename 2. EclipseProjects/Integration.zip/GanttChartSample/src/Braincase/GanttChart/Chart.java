package Braincase.GanttChart;

import java.util.ArrayList;

import com.javonet.Javonet;
import com.javonet.JavonetException;
import com.javonet.api.INEventListener;
import com.javonet.api.NControlContainer;
import com.javonet.api.NEnum;
import com.javonet.api.NObject;

public class Chart extends NControlContainer {
	private static final long serialVersionUID = 1L;
	
	private ArrayList<ChartListener> chartListeners = new ArrayList<ChartListener>();

	public Chart() throws JavonetException{
		super(Javonet.New(Chart.class.getName()));

		this.getUserControl().addEventListener("TaskSelected", new INEventListener() {

			@Override
			public void eventOccurred(Object[] args) {
				for (ChartListener listener : chartListeners)
				{
					try {
						listener.TaskSelected((NObject)args[0], new TaskMouseEventArgs((NObject)args[1]));
					} catch (JavonetException e) {
						e.printStackTrace();
					}
				}
			}
			
		});
	}
	
	public void setTimeResolution(TimeResolution timeResolution) throws JavonetException
	{
		this.set("TimeResolution", NEnum.fromJavaEnum(timeResolution));
	}
	
	public void init(ProjectManager projectManager) throws JavonetException
	{
		this.invoke("Init",projectManager);
	}

	public void addChartListener(ChartListener toAdd)
	{
		this.chartListeners.add(toAdd);
	}
}
