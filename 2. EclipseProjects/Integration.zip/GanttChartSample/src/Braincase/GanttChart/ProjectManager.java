package Braincase.GanttChart;

import com.javonet.Javonet;
import com.javonet.JavonetException;
import com.javonet.api.NObject;

import System.TimeSpan;

public class ProjectManager {
	private NObject handle;
	
	public ProjectManager() throws JavonetException{
		handle = Javonet.New(this.getClass().getName());
	}
	
	public void add(Task task) throws JavonetException
	{
		handle.invoke("Add",task);
	}
	
	public void setDuration(Task task, TimeSpan duration) throws JavonetException
	{
		handle.invoke("SetDuration",task,duration);
	}
	
	public void setStart(Task task, TimeSpan startDate) throws JavonetException
	{
		handle.invoke("SetStart",task,startDate);
	}
	
	public void setComplete(Task task, float complete) throws JavonetException
	{
		handle.invoke("SetComplete",task,complete);
	}
}
