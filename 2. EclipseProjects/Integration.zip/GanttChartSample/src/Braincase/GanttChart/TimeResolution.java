package Braincase.GanttChart;

public enum TimeResolution {
	   Week,
       Day,
       Hour,
       Minute,
       Second,
}
