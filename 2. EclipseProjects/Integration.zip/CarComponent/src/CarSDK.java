import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;

import com.javonet.Javonet;
import com.javonet.JavonetException;
import com.javonet.JavonetFramework;
import com.javonet.api.NObject;

public class CarSDK {
	
	private NObject handle;
	public CarSDK() {
		try {
			handle = Javonet.New("CarSDK");
		} catch (JavonetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public String RevEngine() {
		try {
			return handle.invoke("RevEngine");
		} catch (JavonetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	static {
		if (!Javonet.isActivated()) {
			try {
				Javonet.activate("javonettester@gmail.com", "t7JB-Yi56-b5M4-Bg42-Jn4g",JavonetFramework.v45);
				AddEmbeddedDllReference("CarComponent.dll");
			} catch (JavonetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}        	
		}
	}
	private static void AddEmbeddedDllReference(String fileName) throws IOException, JavonetException{
    	ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    	InputStream input = classLoader.getResourceAsStream(fileName);
    	byte[] dllBytes = IOUtils.toByteArray(input);   	
    	Javonet.addReference(fileName,dllBytes);
  }

}
