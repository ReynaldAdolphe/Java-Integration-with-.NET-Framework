import java.nio.file.Files;
import java.nio.file.Paths;
import com.javonet.Javonet;
import com.javonet.JavonetException;
import com.javonet.JavonetFramework;
import com.javonet.api.NEnum;
import com.javonet.api.NObject;

// Reference: https://github.com/codetuner/Arebis.Pdf

public class ArebisPdfJavaApp {

	public static void main(String[] args) throws JavonetException, InterruptedException {
		
		//Javonet activation
		
		// Referencing XML for activation
		
		//Library reference
		Javonet.addReference("Arebis.Pdf.dll");
		
		// Create a TextOptions object:
	    NObject to = Javonet.New("PdfTextOptions");
        
        // Write the document:
        NObject stream = Javonet.New("FileStream","My_New_PDF_Doc.pdf", 
        								new NEnum("FileMode","Create"), 
        								new NEnum("FileAccess","Write"));
        
        NObject writer = Javonet.New("PdfDocumentWriter",stream,null);
        
        // Write a page:
        NObject page = writer.invoke("NewPage",
        								new Object[]{Javonet.getType("PdfPageFormat").get("A4Portrait")});
        
        
        // Begin reading file
        String content = "";
        try {
			content = readFileAsString("C:\\temp\\file.txt");
		} catch (Exception e) {
			e.printStackTrace();
		}

        //End reading -----------------------------------------------------------------------
        
        // Draw text on the page (with given TextOptions):
        Javonet.getType("PdfPageWriterExtensions").invoke("DrawText",page,40, 800, content, to, 0);
        
        // Close resources
        page.invoke("Close");
        writer.invoke("Close");
        stream.invoke("Close");
	}

	public static String readFileAsString(String fileName)throws Exception
	  {
	    String data = "";
	    data = new String(Files.readAllBytes(Paths.get(fileName)));
	    return data;
	  }
}
