

public class MyFinalClass {

	public static void main(String[] args) {
		System.out.println("\nExercise 04_06\n---------------");
			
		CarSDK secondClassObj = new CarSDK();
		String result = secondClassObj.RevEngine();
		System.out.println(result);	

	}

}
